# QUANT review bundle — round 7

Integration HEAD (local only): `1ae3a7439f683a824708ad2356ee812f8f3cc5d7`
main (unchanged): `953dac24e6065edad9e6913a46e17b66d03bc7a1` · 7 open PRs · no merges · no independent approvals

| PR | Branch | Head | Run | Conclusion |
|---|---|---|---:|---|
| #47 | `fix/dataset-contract-security` | `4049c10d` | `45950530479` | success |
| #48 | `fix/risk-authorization-context` | `a504ee4b` | `45901330470` | success |
| #49 | `fix/oms-state-replay-invariants` | `4cc1bd71` | `45901458799` | success |
| #50 | `fix/publication-filesystem-boundary` | `bf244b1e` | `45901509211` | success |
| #51 | `fix/kdbx-orphan-recovery` | `3a511b64` | `45900959546` | success |
| #52 | `fix/research-report-scope` | `afe3fc50` | `45889261933` | success |
| #53 | `docs/release-truth` | `1a0795f8` | `45950769648` | success |

R6-01 closed: versioned `csv_schema` v2/v3, validated and preserved open
interest, explicit `-1` unavailable sentinel, legacy handling, and expanded
timestamp edge tests. Register now separates implementation, verification and
independent acceptance with blocked-by fields.

NO TRADE. Live execution DISABLED. Holdout SEALED_NOT_EVALUATED.

## SHA-256 manifest

| Path | Bytes | SHA-256 |
|---|---:|---|
| `.clang-format` | 533 | `27a82faf740407c06e94a75487e067601c64bc187fc3e1f58c9f7b77eeb18c75` |
| `.clang-tidy` | 213 | `5d6516e4bf6cfea9ebe457fd62d3d6f2bbbe92f0440a55c6759c8fc11abfee6f` |
| `.gitattributes` | 259 | `22e47d746a4da24b7f227a0269bab8c118a44d75274e001e6803a950ceb0bc90` |
| `.github/workflows/ci.yml` | 4925 | `71afbc202ee09701e9b88d156d07491b5d2c19169f47e4092edfaa1ec8ac8dcf` |
| `.gitignore` | 219 | `89762aa0546764c8653346613ac38f79eb6cdc66f7a9b443944263c6b52b4716` |
| `.pre-commit-config.yaml` | 604 | `a2ef9badc0c88499d4e3d36182ed63800f5201971f99861b478d13c0358e72ee` |
| `.pylint.rc` | 605 | `1d5e360b3395a5d88da878621862b6b62fc4f3b81bf685cbf9c51c29214b7466` |
| `.pylintrc` | 605 | `1d5e360b3395a5d88da878621862b6b62fc4f3b81bf685cbf9c51c29214b7466` |
| `AGENTS.md` | 1218 | `a636a5ee6713e2985912c48421ef0130037ad5990b8df82f38ffb940c4b12b3c` |
| `ASSESSMENT.md` | 4213 | `19c6c93950205d07c890e14beab5bcb557e903cbc2cbacfd6271c3fbe0a6c506` |
| `CMakeLists.txt` | 4728 | `e140c4ea2e52c4faf8faed97bb7a65d5260e9180f7a86bd778d8a75c875271a9` |
| `CMakePresets.json` | 1744 | `372ab088a8ae511037ff681f8eb8700264bf536d99e4a7238e014d97efe75c49` |
| `CONTRIBUTING.md` | 1308 | `ef72300f9b771751947b5fe3b26f902d7b68f32beac76159e7613afcff050277` |
| `README.md` | 10216 | `7943f772660beb677140abbb6abc54aded9f6b3aa1335b84825c3b2532c54a9e` |
| `STYLES.md` | 994 | `7797d5552320be6ebec2de6940505674715bb661bdf2ecf2248b713c09e41636` |
| `config.toml` | 2450 | `e2bbccbe748ebbc3a21f861e9336f2739107ce1bebd878e3b9e100498100c0e7` |
| `data/review-fixtures/dataset-adversarial/duplicate-json-key/contract.json` | 502 | `2c67e6f84f6d2ba130f2a97cf173d3d78a0f845982b20654a433ed7c53516dcd` |
| `data/review-fixtures/dataset-adversarial/duplicate-json-key/manifest.json` | 1098 | `01363043121c728e44ef97f1ca3211d5d4219c64510bd868c37c1f40620419d0` |
| `data/review-fixtures/dataset-adversarial/duplicate-json-key/sda1eaef565ece06433d2ce121b863bb.csv` | 95 | `e120d62b55f29993df8f99e560e64890ac0af39437f5b0272a0cb01385758738` |
| `data/review-fixtures/dataset-adversarial/external-contract.json` | 479 | `db41be4c803153ca32ba1210ef6e3adff9e728a523f182591e13f829e1d2b5de` |
| `data/review-fixtures/dataset-adversarial/external-manifest.json` | 1098 | `01363043121c728e44ef97f1ca3211d5d4219c64510bd868c37c1f40620419d0` |
| `data/review-fixtures/dataset-adversarial/manifest-expectations-mismatch/contract.json` | 414 | `dd349db8b0fdb9514609fe97c88fc0f00c0c3d0240b2869a61fc1590cfe40d80` |
| `data/review-fixtures/dataset-adversarial/manifest-expectations-mismatch/manifest.json` | 909 | `fdac8155e9d87203e6fb24ae5e21593b31e797517a16030ccc9841a18e97896e` |
| `data/review-fixtures/dataset-adversarial/manifest-expectations-mismatch/sda1eaef565ece06433d2ce121b863bb.csv` | 95 | `e120d62b55f29993df8f99e560e64890ac0af39437f5b0272a0cb01385758738` |
| `data/review-fixtures/dataset-adversarial/path-traversal-symbol/contract.json` | 420 | `a27ace62ca8d9ef8678e8319bb1fb84408284449e51be760611ae7905711ce30` |
| `data/review-fixtures/dataset-adversarial/path-traversal-symbol/manifest.json` | 923 | `b2fca308ac12c49862bc29670c91a3a51e5dfe4c4fab03f93ca0a6e30ac078f9` |
| `data/review-fixtures/dataset-adversarial/path-traversal-symbol/sda1eaef565ece06433d2ce121b863bb.csv` | 95 | `e120d62b55f29993df8f99e560e64890ac0af39437f5b0272a0cb01385758738` |
| `data/review-fixtures/dataset-adversarial/range-mismatch/contract.json` | 414 | `d3a611ff8b97c64ee8b428654a931b27740bdb6222c22d95b765084ad6ae7f1f` |
| `data/review-fixtures/dataset-adversarial/range-mismatch/manifest.json` | 917 | `25891c526958fd44df8ea5338960886caba28f2acfeee2db34a470843a5b2bcd` |
| `data/review-fixtures/dataset-adversarial/range-mismatch/sda1eaef565ece06433d2ce121b863bb.csv` | 95 | `e120d62b55f29993df8f99e560e64890ac0af39437f5b0272a0cb01385758738` |
| `data/review-fixtures/dataset-adversarial/symlink-external.csv` | 95 | `e120d62b55f29993df8f99e560e64890ac0af39437f5b0272a0cb01385758738` |
| `data/review-fixtures/dataset-adversarial/symlink-metadata/contract.json` | 479 | `db41be4c803153ca32ba1210ef6e3adff9e728a523f182591e13f829e1d2b5de` |
| `data/review-fixtures/dataset-adversarial/symlink-metadata/manifest.json` | 1098 | `01363043121c728e44ef97f1ca3211d5d4219c64510bd868c37c1f40620419d0` |
| `data/review-fixtures/dataset-adversarial/symlink-metadata/sda1eaef565ece06433d2ce121b863bb.csv` | 95 | `e120d62b55f29993df8f99e560e64890ac0af39437f5b0272a0cb01385758738` |
| `data/review-fixtures/dataset-adversarial/symlink-objects/contract.json` | 479 | `db41be4c803153ca32ba1210ef6e3adff9e728a523f182591e13f829e1d2b5de` |
| `data/review-fixtures/dataset-adversarial/symlink-objects/manifest.json` | 1098 | `01363043121c728e44ef97f1ca3211d5d4219c64510bd868c37c1f40620419d0` |
| `data/review-fixtures/dataset-adversarial/unsorted-symbols/contract.json` | 481 | `c72b5bccfadb6a30c1c9601ab03d4569e58aa4d9fba04c618759b5873ecaf0ff` |
| `data/review-fixtures/dataset-adversarial/unsorted-symbols/manifest.json` | 1233 | `79b76b5816673184a644089341c870bffc5fa83bd4c232c5144ba1c2bae866a3` |
| `data/review-fixtures/dataset-adversarial/unsorted-symbols/sa25d69820545bec128df9e02140736d.csv` | 95 | `e120d62b55f29993df8f99e560e64890ac0af39437f5b0272a0cb01385758738` |
| `data/review-fixtures/dataset-adversarial/unsorted-symbols/sda1eaef565ece06433d2ce121b863bb.csv` | 95 | `e120d62b55f29993df8f99e560e64890ac0af39437f5b0272a0cb01385758738` |
| `docs/branch-protection-2026-11-26.json` | 1119 | `1271445f591d47fd62c9fb80518c5121f42ef028312c28d9034cf2243c93b189` |
| `docs/branch-protection-2026-11-27.json` | 1774 | `efc2a453071e36ae30b257d3cd02938d644837ebb0be5ebfec8786fff6a3e290` |
| `docs/correctness-baseline-2026-11-25.md` | 3031 | `ba377c95542c1be27b10f718cc2d3a759997c63cf15a814d1a546953bfba6512` |
| `docs/correctness-fixes-2026-11-25.md` | 9625 | `963392af51ec9370bf06fe69290f80616d4451c1365cd81e0b4533bcd2f40ab6` |
| `docs/dataset-contract-v2.md` | 6259 | `940a9fe61c8db27d650a054e240ff7032e388b3f21588eeae544bd9812a6fd51` |
| `docs/execution-compliance-2026-11-26.md` | 4418 | `b9f078f4dfba4ac3c5b20ad9de2da793fd22fe8a8ff9168c15e73642817e334e` |
| `docs/financial-integrity-2026-11-26.md` | 11071 | `04fbbdfa70ef1a98ffd2ef623c6c34a85e9ad25387d62bc5ed21cf629cb8be04` |
| `docs/git-state-2026-11-25.md` | 2556 | `2eabc67822d62be9ea75e846fde6f37914495a08b53603cbb53de3a17610707b` |
| `docs/git-workflow.md` | 3060 | `f25470d84dff2343829e6e84600684250c1a9f53a2f3c5523c2fd97242ddcea8` |
| `docs/master-acceptance-register.md` | 6378 | `f11906d84a7072097f13e1f2d5bfccc92f3a11ec1688eecc363d3e90f892d226` |
| `docs/provider-timestamp-policy.md` | 1013 | `f9109644e9597d4864cf889145ab8fbc8e39b309df13b91d899faa0b8347ad8b` |
| `docs/release-status-2026-11-26.md` | 6067 | `718af22fb0a2165b9d5cbd70ef3ab344e968d8b4a239234cc10b9aad0145bfc4` |
| `docs/risk-authorization-model.md` | 1232 | `310f3740e7d87acc453c67e2b769eadd85f87c35db605e68b5e90e75e5312293` |
| `evidence/branch-protection.json` | 1432 | `59741f72e3971a2e4e38608ddea47fa87686e46f22282214eeebe0b4ddece989` |
| `evidence/prs/pr-47.json` | 273 | `b8628d3e8e4db62eac95d65b70b7d9d69ed825500d3bfc1486242edecd295545` |
| `evidence/prs/pr-48.json` | 274 | `b66e6f83f0fcc3f85ff4b0800c27941288f38727ec2f201faf505aa75ad24ff8` |
| `evidence/prs/pr-49.json` | 275 | `3b77bb1da9481efd593f8e20a1657c8bd215c241ff38015a50b02b39da424214` |
| `evidence/prs/pr-50.json` | 279 | `7d8d87a5624c4cf32ca4f73719942f601b21f74cebc5ea425520b1aa4a327ef2` |
| `evidence/prs/pr-51.json` | 268 | `faffbc8d803c5566410688865baf0ce2e3520aca028c170265e2b73559778a53` |
| `evidence/prs/pr-52.json` | 269 | `750c8b8a2a168b0e5ccd8383251e2a59387c132e4f669c54e6dfb13108a67f15` |
| `evidence/prs/pr-53.json` | 262 | `1bcc48664085fa3511e5949d3bae9051f027d8681bd4cbabc2fab830534e991e` |
| `evidence/verification.txt` | 140 | `206fbea6e93195c4d8a27a00fb78e8a5e3f89afcf0e191ef3d74d91a66fbc918` |
| `git-policy.json` | 5403 | `7b2a93e92c334ff9354f68c56ae8b2a7d0d64082c657688c35c888450c1acc1e` |
| `include/quant.hpp` | 55363 | `dedbd2c50e52440af83409f8f0fbb1b055211f5848613de6161cdec36729c8c1` |
| `pyproject.toml` | 618 | `f75df4c88780ad3936f7919afe060ce1bd6d6e46a4ecb8660f9848f245f52883` |
| `python/dataset_contract.py` | 24977 | `a478cc19d43b3657df6678116a85eda4dff9a4441c541823781a86c49b8c7bb2` |
| `python/research.py` | 71820 | `454ef3d8e694d77df8b8a09d0da337c334f28361febe95546bc12752c0f164ad` |
| `q/qstyle.toml` | 489 | `8e4392d3000da3507de180298a52d29fa3d034b297e1e43d7516866e7bdf9be0` |
| `q/quant.q` | 21945 | `32b9c33da8a3981c846147c8a76066bc963438ab1cab4c568cea2aa8051dca87` |
| `references/cppguide.html` | 427668 | `bdac9c1d0b5ddbc7622b696a8f049a6ca172a1dd2190d55b970afd1c15060c63` |
| `references/docguide-style.html` | 50468 | `c7657bd8a5bdb13e5172c4136af9003c4d28a56e1f78a4f56f0217cb9cdd8d95` |
| `references/index.md` | 1855 | `9e0190c213808316943bc7b80d67cf1d3bfa1a59d541a89ceda10c6699748318` |
| `references/jsoncguide.html` | 122428 | `be7fdbbf2cca0d00e947ba6efbaef977a84c6b7d1cd371d5e2fceb2abcb23386` |
| `references/markdown-guide.html` | 29907 | `9334da64ccb699bd7ca345f736f445b3c37c5c6b1890589a2a369ca6e129d276` |
| `references/pyguide.html` | 262460 | `c81fe3405693a6b4f6e14d625b7176eab45754eef1ee76baae270abf15fec147` |
| `references/qbists-style.html` | 114995 | `4e827701d5dff802288d3ec27e7ddb193e55676cde5f622406e0894b88567ef6` |
| `references/shellguide.html` | 96860 | `7a5fe550de49a336fd7a4f8a5fbd78614054925443aa1c3df2bff1a98e593e30` |
| `requirements.txt` | 131 | `6985778556aec0e688e2dbc188584e058f02d057227b422cc65dc7c6cc81bb2e` |
| `ruff.toml` | 295 | `4c79ddbeca33e85fe01a8f32833128c6139c928f116e551e0141b409eb3df479` |
| `scripts/assurance.py` | 24949 | `bfef2d087a783355d92a0fdf5533e818ff7c19b5f215893c7fdc8a684f7d544a` |
| `scripts/check_git_policy.py` | 5633 | `4beba9b9551d4838d0cad07276bf93409062add17fbfb1a6c851ab3bf8cc7a6b` |
| `scripts/style_contract.py` | 7838 | `2a49067df317dd731e322249111aba4911c49a7970716d9dc184d3268e183a47` |
| `src/contract_tool.cpp` | 4192 | `14d07c3c11a0213c3157034a99899d00eeb545513cf1dd09f12c514bad802f73` |
| `src/dataset.cpp` | 36760 | `749ff8d17e0ffa6f3f8b3ce867bf6b57c8f77570733508aeb5badb5ef2e3bfe3` |
| `src/engine.cpp` | 200526 | `653d971519f41080588d115b67fb671a3723af4b123c7cdc7e06df108c8ea663` |
| `src/kdbx.cpp` | 16033 | `cfbb7c49e18c2ecf60977ec0efd72ecd96561ed9107c8e01db6c4a0f9305040e` |
| `src/main.cpp` | 50545 | `60cd7ee5ece274381ec31c76c732b3148e6f0ed747363c9d5d63cf6f7add3505` |
| `src/market_data.cpp` | 54389 | `288406496fabfbac03896c8a8475ba189d5fe3f5dc2f4f2b210c632c171ab19b` |
| `src/zerodha.cpp` | 7517 | `6504c3bc2a0d77985eeeab515a263c9f2e25757b264e6f5e01bb15a43143f36c` |
| `tests/fixtures/canonical_dates.csv` | 242 | `7e3a808789030350d90a689c4de6c3ac89e4547a6ed502624dbdabd7771e72db` |
| `tests/test_dataset_adversarial.py` | 9425 | `cb2009cc13cf83ee0e2ae8be47b00cf4fe372eb1473e5558ed97bb8c7ed488a4` |
| `tests/test_dataset_contract.py` | 6418 | `68a7cdffb69196aef72fcb948bfe3cfbfebd77ee1703cf40439ee758bc92be2a` |
| `tests/test_kdbx.py` | 31492 | `a556a271fc8d59a41c1de2c8ee9ba09e0ad2bca3f1f3dc06fa8dd6f6edbfbb5d` |
| `tests/test_research.py` | 28029 | `11817a01de5e0ba4b41b866448e0aea8de723995e89ed13495e24eb02d14329e` |
| `tests/tests.cpp` | 156485 | `f10d43e174c0e27b96cef6d5ea8302f3a93dbf605617c26aa60bf07f30f693c4` |
